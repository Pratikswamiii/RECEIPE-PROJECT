import time

from appium.webdriver.common.appiumby import AppiumBy

from pages.base_page import BasePage


class UrlsPage(BasePage):

    APP_PACKAGE = "com.android.chrome"

    TEST_URLS = [
        "https://instagram.com",
        "https://facebook.com",
        "https://youtube.com",
        "https://linkedin.com"
    ]

    BLOCKED_KEYWORDS = [

        "site can't be reached",
        "this site can’t be reached",
        "err_connection",
        "connection reset",
        "dns_probe_finished",
        "access denied",
        "blocked",
        "restricted",
        "unable to connect",
        "no internet",
        "network error",
        "timed out",
        "proxy error",
        "server unreachable"
    ]

    def open_browser(self):

        print("Launching Chrome...")

        self.launch_app()

        time.sleep(8)

    def open_url(self, url):

        print(f"\nOpening URL: {url}")

        clicked = self.click_element([
            '//*[@resource-id="com.android.chrome:id/search_box_text"]',
            '//*[@resource-id="com.android.chrome:id/url_bar"]'
        ])

        if not clicked:
            print("Failed to open URL bar")
            return False

        time.sleep(2)

        typed = self.type_text([
            '//*[@resource-id="com.android.chrome:id/url_bar"]',
            '//android.widget.EditText'
        ], url)

        if not typed:
            print("Failed to type URL")
            return False

        time.sleep(2)

        self.driver.press_keycode(66)

        print("Waiting for website response...")

        time.sleep(15)

        return True

    def detect_loading_stuck(self):

        try:

            progress_bars = self.driver.find_elements(
                AppiumBy.XPATH,
                "//android.widget.ProgressBar"
            )

            if len(progress_bars) > 0:

                print("Chrome still loading page")

                return True

        except Exception:
            pass

        return False

    def detect_block_page(self):

        source = self.get_page_source().lower()

        for keyword in self.BLOCKED_KEYWORDS:

            if keyword.lower() in source:

                print(f"Blocked keyword detected: {keyword}")

                return True

        return False

    def validate_real_website_loaded(self):

        valid_locators = [

            # images/videos
            "//android.widget.Image",

            "//android.widget.ImageView",

            "//android.widget.VideoView",

            # social/video text
            '//*[contains(@text,"Reel")]',
            '//*[contains(@text,"Watch")]',
            '//*[contains(@text,"Video")]',
            '//*[contains(@text,"Shorts")]',

            # webpage content
            "//android.webkit.WebView"
        ]

        detected = 0

        for locator in valid_locators:

            try:

                elements = self.driver.find_elements(
                    AppiumBy.XPATH,
                    locator
                )

                if len(elements) > 0:
                    detected += 1

            except Exception:
                pass

        print(f"Real webpage elements detected: {detected}")

        return detected >= 2

    def validate_url(self):

        if self.detect_loading_stuck():

            print("Website stuck while loading")

            return False

        if self.detect_block_page():

            print("Blocked page detected")

            return False

        if self.validate_real_website_loaded():

            print("Website loaded successfully")

            return True

        print("Website content not loaded")

        return False

    def validate_blocking(self):

        self.open_browser()

        success = 0
        failed = 0

        for url in self.TEST_URLS:

            opened = self.open_url(url)

            if not opened:

                failed += 1
                continue

            valid = self.validate_url()

            if valid:
                success += 1
            else:
                failed += 1

        print(f"\nSuccessful URLs: {success}")
        print(f"Failed URLs: {failed}")

        blocked = failed >= 2

        return blocked