import time

from pages.base_page import BasePage
from utils.validators import Validators


class SnapchatPage(BasePage):

    APP_PACKAGE = "com.snapchat.android"

    def open_spotlight(self):

        selectors = [
            '//*[contains(@content-desc,"Spotlight")]',
            '//*[contains(@text,"Spotlight")]',
        ]

        return self.click_element(selectors)

    def validate_blocking(self):

        # self.clear_app_data()

        self.launch_app()

        self.open_spotlight()

        successful = 0
        failed = 0

        for i in range(15):

            before = self.driver.page_source

            time.sleep(1)

            after = self.driver.page_source

            changed = Validators.detect_page_change(
                before,
                after
            )

            if changed:
                successful += 1
            else:
                failed += 1

            self.swipe_up()

            time.sleep(3)

        blocked = (
            successful <= 3 or
            failed >= 10
        )

        return blocked