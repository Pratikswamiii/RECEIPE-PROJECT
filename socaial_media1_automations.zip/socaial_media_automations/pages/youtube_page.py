import time

from pages.base_page import BasePage
from utils.validators import Validators


class YouTubePage(BasePage):

    APP_PACKAGE = "com.google.android.youtube"

    SCROLL_COUNT = 15

    def open_shorts(self):

        print("Opening YouTube Shorts...")

        opened = self.click_element([
            '//*[contains(@content-desc,"Shorts")]',
            '//*[contains(@text,"Shorts")]'
        ])

        time.sleep(5)

        return opened

    def reel_loaded(self):

        source = self.get_page_source().lower()

        if Validators.detect_network_error(source):
            return False

        keywords = [
            "like",
            "comments",
            "share",
            "subscribe",
            "shorts",
            "views"
        ]

        for keyword in keywords:
            if keyword.lower() in source:
                return True

        return False

    def scroll_shorts(self):

        loaded_count = 0

        for i in range(self.SCROLL_COUNT):

            print(f"Scrolling Short {i+1}")

            if self.reel_loaded():
                print("Short loaded successfully")
                loaded_count += 1
            else:
                print("Short failed to load")

            self.swipe_up()

            time.sleep(5)

        print(f"\nLoaded Shorts Count: {loaded_count}")

        return loaded_count

    def validate_blocking(self):

        self.launch_app()

        time.sleep(10)

        opened = self.open_shorts()

        if not opened:
            print("Could not open Shorts")
            return True

        loaded = self.scroll_shorts()

        blocked = loaded <= 3

        return blocked