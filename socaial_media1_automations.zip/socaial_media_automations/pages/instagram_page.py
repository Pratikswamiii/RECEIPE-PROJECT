import time

from appium.webdriver.common.appiumby import AppiumBy

from pages.base_page import BasePage
from utils.validators import Validators


class InstagramPage(BasePage):

    APP_PACKAGE = "com.instagram.android"

    def open_reels(self):

        print("Opening Instagram Reels...")

        reels_xpaths = [

            '//*[contains(@content-desc,"Reels")]',

            '//*[contains(@text,"Reels")]',

            '//*[contains(@resource-id,"reels")]'
        ]

        clicked = self.click_element(reels_xpaths)

        time.sleep(5)

        return clicked

    def reel_loaded(self):

        source = self.get_page_source().lower()

        media_keywords = [

            "like",
            "comment",
            "share",
            "reel",
            "audio",
            "send message"
        ]

        for keyword in media_keywords:

            if keyword in source:
                return True

        if Validators.detect_network_error(source):
            return False

        return False

    def scroll_reels(self, count=15):

        loaded_count = 0

        for i in range(count):

            print(f"Scrolling Reel {i + 1}")

            if self.reel_loaded():

                loaded_count += 1

                print("Reel loaded successfully")

            else:

                print("Reel failed to load")

            self.driver.swipe(
                500,
                1700,
                500,
                400,
                400
            )

            time.sleep(4)

        return loaded_count

    def validate_blocking(self):

        self.launch_app()

        time.sleep(10)

        opened = self.open_reels()

        if not opened:

            print("Unable to open reels")

            return True

        loaded = self.scroll_reels(15)

        print(f"\nLoaded Reels Count: {loaded}")

        blocked = loaded <= 3

        return blocked