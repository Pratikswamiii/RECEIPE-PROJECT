import time

from appium.webdriver.common.appiumby import AppiumBy

from pages.base_page import BasePage


class TelegramPage(BasePage):

    APP_PACKAGE = "org.telegram.messenger"

    TEST_MESSAGES = [
        "hi",
        "hello",
        "telegram_test"
    ]

    def open_recent_chat(self):

        time.sleep(10)

        selectors = [
            "//androidx.recyclerview.widget.RecyclerView/android.view.ViewGroup",
            "//android.widget.FrameLayout"
        ]

        for selector in selectors:

            try:
                chats = self.driver.find_elements(
                    AppiumBy.XPATH,
                    selector
                )

                if chats and len(chats) > 1:

                    chats[1].click()

                    print("Recent chat opened")

                    return True

            except:
                pass

        return False

    def send_message(self, message):

        try:

            input_box = self.driver.find_element(
                AppiumBy.XPATH,
                "//android.widget.EditText"
            )

            input_box.click()

            input_box.send_keys(message)

            time.sleep(2)

            send_buttons = self.driver.find_elements(
                AppiumBy.XPATH,
                '//*[contains(@content-desc,"Send")]'
            )

            if send_buttons:

                send_buttons[-1].click()

                print(f"Message sent -> {message}")

                time.sleep(5)

                page_source = self.driver.page_source.lower()

                failure_keywords = [
                    "retry",
                    "failed",
                    "waiting for network",
                    "connecting",
                    "no internet"
                ]

                for keyword in failure_keywords:

                    if keyword in page_source:

                        print(
                            f"Message failed -> {keyword}"
                        )

                        return False

                return True

        except Exception as e:

            print(f"Send message failed: {e}")

        return False

    def validate_blocking(self):

        self.launch_app()

        chat_opened = self.open_recent_chat()

        if not chat_opened:

            return True

        success = 0
        failed = 0

        for message in self.TEST_MESSAGES:

            result = self.send_message(message)

            if result:
                success += 1
            else:
                failed += 1

        print(f"\nSuccessful: {success}")
        print(f"Failed: {failed}")

        if failed >= 2:
            return True

        return False