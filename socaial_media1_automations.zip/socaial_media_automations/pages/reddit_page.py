import time

from pages.base_page import BasePage
from utils.validators import Validators


class RedditPage(BasePage):

    APP_PACKAGE = "com.reddit.frontpage"

    def validate_blocking(self):

        # self.clear_app_data()

        self.launch_app()

        error_detected = False
        feed_loaded = False

        for i in range(5):

            print(f"Checking Reddit Feed {i+1}/5")

            source = self.get_page_source()

            if Validators.detect_network_error(source):
                error_detected = True

            content_keywords = [
                "upvote",
                "comments",
                "share",
                "join",
                "r/"
            ]

            count = 0

            for keyword in content_keywords:

                if keyword in source:
                    count += 1

            if count >= 2:
                feed_loaded = True

            time.sleep(5)

        blocked = (
            error_detected or
            not feed_loaded
        )

        return blocked