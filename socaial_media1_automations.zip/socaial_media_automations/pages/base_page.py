import time

from appium.webdriver.common.appiumby import AppiumBy

from utils.gestures import Gestures
from utils.config import *


class BasePage:

    def __init__(self, driver, app_package):

        self.driver = driver
        self.app_package = app_package

    # =====================================================
    # APP CONTROLS
    # =====================================================

    def launch_app(self):

        print(f"Launching {self.app_package}")

        self.driver.activate_app(self.app_package)

        time.sleep(WAIT_TIME)

    def close_app(self):

        self.driver.terminate_app(self.app_package)

    # def clear_app_data(self):

    #     print("Clearing app data...")

    #     self.close_app()

    #     time.sleep(2)

    #     self.driver.execute_script(
    #         "mobile: shell",
    #         {
    #             "command": "pm",
    #             "args": ["clear", self.app_package]
    #         }
    #     )

        time.sleep(3)

    # =====================================================
    # COMMON HELPERS
    # =====================================================

    def find_element(self, selectors):

        for selector in selectors:

            try:
                elements = self.driver.find_elements(
                    AppiumBy.XPATH,
                    selector
                )

                if elements:
                    return elements[0]

            except:
                pass

        return None

    def click_element(self, selectors):

        element = self.find_element(selectors)

        if element:
            element.click()
            return True

        return False

    def type_text(self, selectors, text):

        element = self.find_element(selectors)

        if not element:
            return False

        element.click()

        time.sleep(1)

        element.send_keys(text)

        return True

    def get_page_source(self):

        return self.driver.page_source.lower()

    def swipe_up(self):

        Gestures.swipe_up(self.driver)

    def take_screenshot(self, name):

        self.driver.save_screenshot(
            f"screenshots/{name}.png"
        )