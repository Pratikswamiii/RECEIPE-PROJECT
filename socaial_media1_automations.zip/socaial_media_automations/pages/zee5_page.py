import time

from appium.webdriver.common.appiumby import AppiumBy

from pages.base_page import BasePage
from utils.validators import Validators


class Zee5Page(BasePage):

    APP_PACKAGE = "com.graymatrix.did"

    SEARCH_TEXT = "ipl"

    WATCH_DURATION = 300

    def open_search(self):

        print("Opening ZEE5 search...")

        time.sleep(10)

        search_opened = self.click_element([
            # Search icon beside language selector
            '//*[contains(@content-desc,"Search")]',
            '//*[contains(@resource-id,"search")]',
            '//android.widget.ImageView[contains(@content-desc,"Search")]',
            '//android.widget.FrameLayout[contains(@resource-id,"search")]'
        ])

        if not search_opened:
            print("Failed to open search icon")
            return False

        time.sleep(4)

        return True

    def search_ipl(self):

        print("Searching IPL...")

        search_box = self.find_element([
            '//android.widget.EditText',
            '//*[contains(@resource-id,"search_src_text")]',
            '//*[contains(@text,"Search")]'
        ])

        if not search_box:
            print("Search box not found")
            return False

        try:
            search_box.click()
            search_box.clear()
            search_box.send_keys(self.SEARCH_TEXT)
        except Exception as e:
            print(f"Failed typing search text: {e}")
            return False

        time.sleep(3)

        # Press enter/search from keyboard
        try:
            self.driver.press_keycode(66)
        except:
            pass

        time.sleep(8)

        return True

    def open_first_video(self):

        print("Opening first IPL video...")

        opened = self.click_element([
            # Video cards
            '(//android.widget.ImageView)[1]',
            '(//android.view.ViewGroup)[1]',
            '(//android.widget.FrameLayout)[1]'
        ])

        if not opened:
            print("Unable to open first video")
            return False

        time.sleep(15)

        return True

    def validate_video_playing(self):

        print("Validating video playback for 5 minutes...")

        start_time = time.time()

        success_count = 0

        while time.time() - start_time < self.WATCH_DURATION:

            source = self.get_page_source().lower()

            network_error = Validators.detect_network_error(source)

            playback_indicators = [
                "pause",
                "playing",
                "buffer",
                "player",
                "seek",
                "watch",
                "video"
            ]

            playback_detected = any(
                text in source for text in playback_indicators
            )

            if network_error:
                print("Network error detected")
                return False

            if playback_detected:
                success_count += 1
                print(f"Playback active... {success_count}")

            time.sleep(15)

        return success_count >= 10

    def validate_blocking(self):

        self.launch_app()

        if not self.open_search():
            return True

        if not self.search_ipl():
            return True

        if not self.open_first_video():
            return True

        played = self.validate_video_playing()

        blocked = not played

        return blocked