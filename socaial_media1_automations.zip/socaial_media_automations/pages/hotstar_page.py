import time

from appium.webdriver.common.appiumby import AppiumBy

from pages.base_page import BasePage
from utils.validators import Validators


class HotstarPage(BasePage):

    APP_PACKAGE = "in.startv.hotstar"

    SEARCH_TEXT = "ipl"

    WATCH_DURATION = 300

    def open_search(self):

        print("Opening Hotstar search...")

        return self.click_element([
            '//*[contains(@content-desc,"Search")]',
            '//*[contains(@text,"Search")]',
            '//*[contains(@resource-id,"search")]'
        ])

    def search_ipl(self):

        print(f"Searching for: {self.SEARCH_TEXT}")

        time.sleep(3)

        try:

            search_boxes = self.driver.find_elements(
                AppiumBy.CLASS_NAME,
                "android.widget.EditText"
            )

            if not search_boxes:
                return False

            search_box = search_boxes[0]

            search_box.click()
            search_box.send_keys(self.SEARCH_TEXT)

            time.sleep(5)

            self.driver.press_keycode(66)

            return True

        except Exception as e:
            print(f"Search failed: {e}")
            return False

    def open_video(self):

        print("Opening IPL video...")

        time.sleep(8)

        return self.click_element([
            '(//android.widget.ImageView)[1]',
            '(//android.view.ViewGroup)[1]',
            '//*[contains(@text,"IPL")]'
        ])

    def validate_video_playing(self):

        print("Validating playback for 5 minutes...")

        start = time.time()

        success_checks = 0

        while time.time() - start < self.WATCH_DURATION:

            source = self.get_page_source().lower()

            if Validators.detect_network_error(source):
                print("Network error detected")
                return False

            playback_keywords = [
                "pause",
                "playing",
                "live",
                "watch",
                "video"
            ]

            for keyword in playback_keywords:
                if keyword in source:
                    success_checks += 1
                    break

            print(f"Playback validation count: {success_checks}")

            time.sleep(20)

        return success_checks >= 5

    def validate_blocking(self):

        self.launch_app()

        time.sleep(15)

        if not self.open_search():
            return True

        if not self.search_ipl():
            return True

        if not self.open_video():
            return True

        played = self.validate_video_playing()

        return not played