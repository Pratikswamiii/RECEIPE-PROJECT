import time

from appium.webdriver.common.appiumby import AppiumBy

from pages.base_page import BasePage
from utils.validators import Validators


class LinkedinPage(BasePage):

    APP_PACKAGE = "com.linkedin.android"

    SEARCH_TEXT = "jio"

    def open_search(self):

        print("Opening LinkedIn search...")

        opened = self.click_element([
            '//*[contains(@content-desc,"Search")]',
            '//*[contains(@text,"Search")]',
            '//*[contains(@resource-id,"search")]'
        ])

        time.sleep(4)

        return opened

    def perform_search(self):

        print(f"Searching for: {self.SEARCH_TEXT}")

        # Click actual search textbox first
        clicked = self.click_element([
            '//android.widget.EditText',
            '//*[contains(@text,"Search")]',
            '//*[contains(@resource-id,"search_bar")]'
        ])

        time.sleep(2)

        if not clicked:
            print("Search textbox not found")
            return False

        try:

            elements = self.driver.find_elements(
                AppiumBy.CLASS_NAME,
                "android.widget.EditText"
            )

            if not elements:
                print("No editable textbox found")
                return False

            search_box = elements[0]

            search_box.clear()
            search_box.click()

            time.sleep(1)

            search_box.send_keys(self.SEARCH_TEXT)

            time.sleep(3)

        except Exception as e:
            print(f"Typing failed: {e}")
            return False

        # Press enter/search from keyboard
        try:
            self.driver.press_keycode(66)
        except:
            pass

        time.sleep(8)

        return True

    def validate_results(self):

        print("Validating LinkedIn results...")

        source = self.get_page_source().lower()

        if Validators.detect_network_error(source):
            print("Network error detected")
            return True

        keywords = [
            "jio",
            "people",
            "posts",
            "companies",
            "jobs"
        ]

        for keyword in keywords:

            if keyword.lower() in source:
                print(f"Loaded keyword found: {keyword}")
                return False

        print("No search results loaded")
        return True

    def validate_blocking(self):

        self.launch_app()

        time.sleep(10)

        opened = self.open_search()

        if not opened:
            print("Could not open search")
            return True

        searched = self.perform_search()

        if not searched:
            print("Search operation failed")
            return True

        blocked = self.validate_results()

        print(f"\nLINKEDIN BLOCKED: {blocked}")
        return blocked