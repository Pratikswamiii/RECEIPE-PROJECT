import time

from pages.base_page import BasePage
from utils.validators import Validators


class WhatsAppPage(BasePage):

    APP_PACKAGE = "com.whatsapp"

    TEST_MESSAGES = [
        "testing",
        "hello",
        "layer7"
    ]

    def open_first_chat(self):

        print("Opening first available chat...")

        time.sleep(5)

        possible_xpaths = [

            # WhatsApp chat list rows
            '(//androidx.recyclerview.widget.RecyclerView/*)[1]',

            '(//*[contains(@resource-id,"conversation_row")])[1]',

            '(//*[contains(@resource-id,"contact_row")])[1]',

            '(//android.widget.ListView/*)[1]'
        ]

        for xpath in possible_xpaths:

            try:

                clicked = self.click_element([xpath])

                if clicked:

                    print("Chat opened successfully")

                    time.sleep(3)

                    return True

            except Exception:
                pass

        print("No chat found")

        return False

    def send_message(self, message):

        print(f"Sending message: {message}")

        message_box_xpaths = [

            '//android.widget.EditText',

            '//*[contains(@resource-id,"entry")]',

            '//*[contains(@resource-id,"message_input")]'
        ]

        typed = self.type_text(
            message_box_xpaths,
            message
        )

        if not typed:

            print("Failed typing message")

            return False

        send_button_xpaths = [

            '//*[contains(@content-desc,"Send")]',

            '//*[contains(@resource-id,"send")]',

            '//*[contains(@resource-id,"send_button")]'
        ]

        send_clicked = self.click_element(
            send_button_xpaths
        )

        if not send_clicked:

            print("Send button click failed")

            return False

        print("Message sent. Validating network state...")

        time.sleep(8)

        source = self.get_page_source()

        if Validators.detect_network_error(source):

            print("Network error detected")

            return False

        print("Message delivered successfully")

        return True

    def validate_blocking(self):

        self.launch_app()

        time.sleep(10)

        opened = self.open_first_chat()

        if not opened:

            print("Unable to open any chat")

            return True

        success = 0
        failed = 0

        for msg in self.TEST_MESSAGES:

            result = self.send_message(msg)

            if result:
                success += 1
            else:
                failed += 1

            time.sleep(3)

        print(f"\nSuccess Count : {success}")
        print(f"Failed Count  : {failed}")

        blocked = failed >= 2

        return blocked