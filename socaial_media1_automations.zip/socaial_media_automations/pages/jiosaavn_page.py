import time

from appium.webdriver.common.appiumby import AppiumBy

from pages.base_page import BasePage
from utils.validators import Validators


class JioSaavnPage(BasePage):

    APP_PACKAGE = "com.jio.media.jiobeats"

    SEARCH_TEXT = "perfect"

    PLAY_DURATION = 30

    def open_search(self):

        print("Opening JioSaavn search...")

        time.sleep(8)

        opened = self.click_element([
            '//*[contains(@content-desc,"Search")]',
            '//*[contains(@resource-id,"search")]',
            '//android.widget.TextView[contains(@text,"Search")]'
        ])

        if not opened:
            print("Search button not found")
            return False

        time.sleep(4)

        return True

    def search_song(self):

        print(f"Searching song: {self.SEARCH_TEXT}")

        search_box = self.find_element([
            '//android.widget.EditText',
            '//*[contains(@resource-id,"search")]'
        ])

        if not search_box:
            print("Search box not found")
            return False

        try:

            search_box.click()

            search_box.clear()

            search_box.send_keys(self.SEARCH_TEXT)

        except Exception as e:

            print(f"Failed typing song name: {e}")

            return False

        time.sleep(3)

        try:
            # ENTER key
            self.driver.press_keycode(66)
        except:
            pass

        time.sleep(8)

        return True

    def open_first_song(self):

        print("Opening first song...")

        locators = [

            # First result text
            '(//android.widget.TextView)[1]',

            # Recycler view item
            '(//androidx.recyclerview.widget.RecyclerView//*[@clickable="true"])[1]',

            # Generic clickable
            '(//*[@clickable="true"])[10]'
        ]

        for locator in locators:

            try:

                print(f"Trying locator: {locator}")

                elements = self.driver.find_elements(
                    AppiumBy.XPATH,
                    locator
                )

                if len(elements) == 0:
                    continue

                elements[0].click()

                time.sleep(10)

                source = self.get_page_source().lower()

                playback_keywords = [
                    "pause",
                    "play",
                    "next",
                    "like"
                ]

                playback_screen = any(
                    keyword in source
                    for keyword in playback_keywords
                )

                if playback_screen:

                    print("Song playback screen opened")

                    return True

            except Exception as e:

                print(f"Locator failed: {locator}")
                print(e)

        print("Unable to open song")

        return False

    def validate_song_playing(self):

        print("Validating song playback...")

        start_time = time.time()

        success_checks = 0

        while time.time() - start_time < self.PLAY_DURATION:

            source = self.get_page_source().lower()

            network_error = Validators.detect_network_error(source)

            playback_controls = [
                "pause",
                "play",
                "next",
                "like"
            ]

            playback_detected = any(
                keyword in source
                for keyword in playback_controls
            )

            if network_error:

                print("Network error detected")

                return False

            if playback_detected:

                success_checks += 1

                print(
                    f"Playback active... "
                    f"{success_checks}"
                )

            else:

                print("Playback controls not visible")

            time.sleep(5)

        return success_checks >= 4

    def validate_blocking(self):

        self.launch_app()

        if not self.open_search():
            return True

        if not self.search_song():
            return True

        if not self.open_first_song():
            return True

        played = self.validate_song_playing()

        blocked = not played

        return blocked