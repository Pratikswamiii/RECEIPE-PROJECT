import time

from appium.webdriver.common.appiumby import AppiumBy

from pages.base_page import BasePage
from utils.validators import Validators


class SonyLivPage(BasePage):

    APP_PACKAGE = "com.sonyliv"

    SEARCH_TEXT = "ipl"

    WATCH_DURATION = 300

    def open_search(self):

        print("Opening Sony LIV search...")

        time.sleep(10)

        opened = self.click_element([
            '//*[contains(@content-desc,"Search")]',
            '//*[contains(@resource-id,"search")]',
            '//android.widget.ImageView[contains(@content-desc,"Search")]'
        ])

        if not opened:
            print("Search button not found")
            return False

        time.sleep(5)

        return True

    def search_ipl(self):

        print(f"Searching for: {self.SEARCH_TEXT}")

        search_box = self.find_element([
            '//android.widget.EditText',
            '//*[contains(@resource-id,"search")]'
        ])

        if not search_box:
            print("Search box not found")
            return False

        try:
            search_box.click()
            search_box.clear()
            search_box.send_keys(self.SEARCH_TEXT)

        except Exception as e:
            print(f"Failed typing text: {e}")
            return False

        time.sleep(3)

        try:
            # Android ENTER key
            self.driver.press_keycode(66)
        except:
            pass

        time.sleep(10)

        return True

    def open_first_video(self):

        print("Opening first Sony LIV video...")

        time.sleep(10)

        possible_video_locators = [

            # RecyclerView thumbnails
            '(//androidx.recyclerview.widget.RecyclerView//android.widget.ImageView)[1]',

            # Generic thumbnails
            '(//android.widget.ImageView)[5]',

            # Content cards
            '(//android.view.ViewGroup)[10]',

            # IPL content
            '//*[contains(@content-desc,"IPL")]',
            '//*[contains(@text,"IPL")]',

            # Fallback clickable result
            '(//*[@clickable="true"])[15]'
        ]

        for locator in possible_video_locators:

            try:

                print(f"Trying locator: {locator}")

                elements = self.driver.find_elements(
                    AppiumBy.XPATH,
                    locator
                )

                if len(elements) == 0:
                    continue

                elements[0].click()

                time.sleep(15)

                source = self.get_page_source().lower()

                playback_keywords = [
                    "pause",
                    "player",
                    "video",
                    "buffer",
                    "seek",
                    "play"
                ]

                playback_detected = any(
                    keyword in source
                    for keyword in playback_keywords
                )

                if playback_detected:

                    print("Video playback screen opened")
                    return True

            except Exception as e:

                print(f"Locator failed: {locator}")
                print(e)

        print("Unable to open Sony LIV video")

        return False

    def validate_video_playing(self):

        print("Validating playback for 5 minutes...")

        start_time = time.time()

        playback_checks = 0

        while time.time() - start_time < self.WATCH_DURATION:

            source = self.get_page_source().lower()

            network_error = Validators.detect_network_error(source)

            playback_keywords = [
                "pause",
                "player",
                "video",
                "seek",
                "buffer",
                "play"
            ]

            playback_detected = any(
                keyword in source
                for keyword in playback_keywords
            )

            if network_error:

                print("Network error detected")
                return False

            if playback_detected:

                playback_checks += 1

                print(
                    f"Playback running... "
                    f"{playback_checks}"
                )

            else:

                print("Playback not detected")

            time.sleep(15)

        return playback_checks >= 10

    def validate_blocking(self):

        self.launch_app()

        if not self.open_search():
            return True

        if not self.search_ipl():
            return True

        if not self.open_first_video():
            return True

        played = self.validate_video_playing()

        blocked = not played

        return blocked