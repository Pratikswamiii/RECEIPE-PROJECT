import time

from pages.base_page import BasePage
from utils.validators import Validators


class NetflixPage(BasePage):

    APP_PACKAGE = "com.netflix.mediaclient"

    def select_profile(self):

        print("Selecting Netflix profile...")

        time.sleep(10)

        clicked = self.click_element([
            '(//android.widget.ImageView)[1]',
            '(//android.view.ViewGroup)[1]'
        ])

        time.sleep(8)

        return clicked

    def click_first_content(self):

        print("Opening first Netflix content...")

        clicked = self.click_element([
            '(//android.widget.ImageView)[3]',
            '(//android.view.ViewGroup)[3]'
        ])

        time.sleep(10)

        return clicked

    def validate_playback(self):

        print("Validating Netflix playback...")

        source = self.get_page_source().lower()

        if Validators.detect_network_error(source):
            print("Network error detected")
            return False

        keywords = [
            "pause",
            "play",
            "episode",
            "next episode",
            "audio",
            "subtitle"
        ]

        for keyword in keywords:

            if keyword.lower() in source:
                print(f"Playback keyword found: {keyword}")
                return True

        return False

    def validate_blocking(self):

        self.launch_app()

        time.sleep(12)

        blocked = False

        self.select_profile()

        opened = self.click_first_content()

        if not opened:
            blocked = True

        elif not self.validate_playback():
            blocked = True

        return blocked