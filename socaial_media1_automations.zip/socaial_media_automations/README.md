# Mobile Blocking Automation Framework

## Install Dependencies

pip install -r requirements.txt

## Start Appium

appium --port 4723

## Run All Tests

pytest

## Run Single Test

pytest tests/test_linkedin.py -v -s

## Run Allure Report

pytest --alluredir=reports

allure serve reports