import pytest

from utils.driver_factory import DriverFactory


@pytest.fixture(scope="function")
def driver(request):

    app_package = request.param

    driver = DriverFactory.create_driver(
        app_package
    )

    yield driver

    try:
        driver.quit()
    except:
        pass