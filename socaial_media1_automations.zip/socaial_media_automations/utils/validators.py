class Validators:

    @staticmethod
    def detect_network_error(page_source):

        error_keywords = [
            "retry",
            "try again",
            "network error",
            "no internet",
            "unable to connect",
            "failed",
            "offline",
            "something went wrong",
            "connection"
        ]

        for keyword in error_keywords:

            if keyword in page_source:
                return True

        return False

    @staticmethod
    def detect_blank_screen(driver):

        elements = driver.find_elements(
            "xpath",
            "//*"
        )

        return len(elements) < 15

    @staticmethod
    def detect_page_change(before, after):

        return before != after