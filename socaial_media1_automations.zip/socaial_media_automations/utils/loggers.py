from loguru import logger

logger.add(
    "reports/framework.log",
    rotation="5 MB",
    level="INFO"
)