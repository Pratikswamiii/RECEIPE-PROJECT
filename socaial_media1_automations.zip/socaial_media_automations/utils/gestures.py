class Gestures:

    @staticmethod
    def swipe_up(driver):

        size = driver.get_window_size()

        x = int(size['width'] * 0.50)

        start_y = int(size['height'] * 0.80)
        end_y = int(size['height'] * 0.20)

        driver.swipe(
            x,
            start_y,
            x,
            end_y,
            500
        )