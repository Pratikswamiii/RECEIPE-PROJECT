from appium import webdriver
from appium.options.android import UiAutomator2Options


# =========================================================
# APPIUM CONFIG
# =========================================================

APPIUM_SERVER_URL = "http://127.0.0.1:4723"

DEVICE_NAME = "Android"

# Replace with your device id from:
# adb devices
DEVICE_UDID = "RZ8MC0NX48Y"


class DriverFactory:

    @staticmethod
    def create_driver(app_package):

        print("Checking Appium server...")
        print(f"Launching {app_package}")

        options = UiAutomator2Options()

        # =========================================================
        # BASIC CAPABILITIES
        # =========================================================

        options.platform_name = "Android"

        options.device_name = DEVICE_NAME

        options.udid = DEVICE_UDID

        options.automation_name = "UiAutomator2"

        options.app_package = app_package

        options.no_reset = True

        options.new_command_timeout = 300

        # =========================================================
        # IMPORTANT STABILITY FIXES
        # =========================================================

        options.set_capability(
            "autoGrantPermissions",
            True
        )

        options.set_capability(
            "ignoreHiddenApiPolicyError",
            True
        )

        options.set_capability(
            "appWaitForLaunch",
            False
        )

        # =========================================================
        # FACEBOOK
        # =========================================================

        if app_package == "com.facebook.katana":

            options.app_activity = (
                "com.facebook.katana.activity.FbMainTabActivity"
            )

        # =========================================================
        # LINKEDIN
        # =========================================================

        elif app_package == "com.linkedin.android":

            options.app_activity = (
                "com.linkedin.android.authenticator.LaunchActivity"
            )

        # =========================================================
        # REDDIT
        # =========================================================

        elif app_package == "com.reddit.frontpage":

            options.app_activity = (
                "com.reddit.launch.main.MainActivity"
            )

        # =========================================================
        # SNAPCHAT
        # =========================================================

        elif app_package == "com.snapchat.android":

            options.app_activity = (
                ".LandingPageActivity"
            )

        # =========================================================
        # TELEGRAM
        # =========================================================

        elif app_package == "org.telegram.messenger":

            options.app_activity = (
                "org.telegram.ui.LaunchActivity"
            )

        # =========================================================
        # WHATSAPP
        # =========================================================

        elif app_package == "com.whatsapp":

            options.app_activity = (
                "com.whatsapp.HomeActivity"
            )

        # =========================================================
        # YOUTUBE
        # =========================================================

        elif app_package == "com.google.android.youtube":

            # DO NOT FORCE ACTIVITY
            # Samsung blocks internal YouTube activities

            pass

        # =========================================================
        # NETFLIX
        # =========================================================

        elif app_package == "com.netflix.mediaclient":

            # Netflix also works better automatically

            pass

        # =========================================================
        # CREATE DRIVER
        # =========================================================

        driver = webdriver.Remote(
            APPIUM_SERVER_URL,
            options=options
        )

        driver.implicitly_wait(10)

        return driver