import pytest

from pages.zee5_page import Zee5Page


EXPECTED_BLOCKED_STATE = True


class TestZee5:

    @pytest.mark.parametrize(
        "driver",
        ["com.graymatrix.did"],
        indirect=True
    )
    def test_zee5_blocking(self, driver):

        page = Zee5Page(
            driver,
            Zee5Page.APP_PACKAGE
        )

        blocked = page.validate_blocking()

        print(f"\nZEE5 BLOCKED: {blocked}")

        assert blocked == EXPECTED_BLOCKED_STATE