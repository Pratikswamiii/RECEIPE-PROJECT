import pytest

from pages.netflix_page import NetflixPage


EXPECTED_BLOCKED_STATE = True


class TestNetflix:

    @pytest.mark.parametrize(
        "driver",
        ["com.netflix.mediaclient"],
        indirect=True
    )
    def test_netflix_blocking(self, driver):

        page = NetflixPage(
            driver,
            NetflixPage.APP_PACKAGE
        )

        blocked = page.validate_blocking()

        print(f"\nNETFLIX BLOCKED: {blocked}")

        assert blocked == EXPECTED_BLOCKED_STATE