import pytest

from pages.reddit_page import RedditPage


@pytest.mark.parametrize(
    "driver",
    [RedditPage.APP_PACKAGE],
    indirect=True
)
class TestReddit:

    def test_reddit_blocking(self, driver):

        page = RedditPage(
            driver,
            RedditPage.APP_PACKAGE
        )

        blocked = page.validate_blocking()

        print(f"\nREDDIT BLOCKED: {blocked}")

        assert True