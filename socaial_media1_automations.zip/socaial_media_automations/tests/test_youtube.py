import pytest

from pages.youtube_page import YouTubePage


EXPECTED_BLOCKED_STATE = True


class TestYouTube:

    @pytest.mark.parametrize(
        "driver",
        ["com.google.android.youtube"],
        indirect=True
    )
    def test_youtube_blocking(self, driver):

        page = YouTubePage(
            driver,
            YouTubePage.APP_PACKAGE
        )

        blocked = page.validate_blocking()

        print(f"\nYOUTUBE BLOCKED: {blocked}")

        assert blocked == EXPECTED_BLOCKED_STATE