import pytest

from pages.linkedin_page import LinkedinPage


@pytest.mark.parametrize(
    "driver",
    [LinkedinPage.APP_PACKAGE],
    indirect=True
)
class TestLinkedin:

    def test_linkedin_blocking(self, driver):

        page = LinkedinPage(
            driver,
            LinkedinPage.APP_PACKAGE
        )

        blocked = page.validate_blocking()

        print(f"\nLINKEDIN BLOCKED: {blocked}")

        assert True