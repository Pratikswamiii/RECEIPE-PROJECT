import pytest

from pages.facebook_page import FacebookPage


# ==========================================
# EXPECTED RESULT
# ==========================================
# True  = Facebook SHOULD be blocked
# False = Facebook SHOULD work normally
# ==========================================

EXPECTED_BLOCKED_STATE = False


class TestFacebook:

    @pytest.mark.parametrize(
        "driver",
        ["com.facebook.katana"],
        indirect=True
    )
    def test_facebook_blocking(self, driver):

        page = FacebookPage(
            driver,
            FacebookPage.APP_PACKAGE
        )

        blocked = page.validate_blocking()

        print("\n===================================")
        print(f"FACEBOOK BLOCKED: {blocked}")
        print(f"EXPECTED STATE : {EXPECTED_BLOCKED_STATE}")
        print("===================================\n")

        if EXPECTED_BLOCKED_STATE:

            assert blocked is True, (
                "Facebook traffic is NOT blocked "
                "but policy expects it to be blocked"
            )

        else:

            assert blocked is False, (
                "Facebook appears blocked "
                "but policy expects it to work"
            )