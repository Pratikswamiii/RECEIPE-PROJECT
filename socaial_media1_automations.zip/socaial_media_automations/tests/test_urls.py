import pytest

from pages.urls_page import UrlsPage


EXPECTED_BLOCKED_STATE = False


class TestUrls:

    @pytest.mark.parametrize(
        "driver",
        ["com.android.chrome"],
        indirect=True
    )
    def test_urls_blocking(self, driver):

        page = UrlsPage(
            driver,
            UrlsPage.APP_PACKAGE
        )

        blocked = page.validate_blocking()

        print(f"\nURL FILTERING BLOCKED: {blocked}")

        assert blocked == EXPECTED_BLOCKED_STATE