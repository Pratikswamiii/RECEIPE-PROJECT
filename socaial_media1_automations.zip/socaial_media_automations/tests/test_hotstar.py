import pytest

from pages.hotstar_page import HotstarPage

EXPECTED_BLOCKED_STATE = False


class TestHotstar:

    @pytest.mark.parametrize(
        "driver",
        ["in.startv.hotstar"],
        indirect=True
    )
    def test_hotstar_blocking(self, driver):

        page = HotstarPage(
            driver,
            HotstarPage.APP_PACKAGE
        )

        blocked = page.validate_blocking()

        print(f"\nHOTSTAR BLOCKED: {blocked}")

        assert blocked == EXPECTED_BLOCKED_STATE