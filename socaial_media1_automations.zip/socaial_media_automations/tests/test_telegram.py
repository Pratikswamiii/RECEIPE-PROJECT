import pytest

from pages.telegram_page import TelegramPage


@pytest.mark.parametrize(
    "driver",
    [TelegramPage.APP_PACKAGE],
    indirect=True
)
class TestTelegram:

    def test_telegram_blocking(self, driver):

        page = TelegramPage(
            driver,
            TelegramPage.APP_PACKAGE
        )

        blocked = page.validate_blocking()

        print(f"\nTELEGRAM BLOCKED: {blocked}")

        assert True