import pytest

from pages.snapchat_page import SnapchatPage


@pytest.mark.parametrize(
    "driver",
    [SnapchatPage.APP_PACKAGE],
    indirect=True
)
class TestSnapchat:

    def test_snapchat_blocking(self, driver):

        page = SnapchatPage(
            driver,
            SnapchatPage.APP_PACKAGE
        )

        blocked = page.validate_blocking()

        print(f"\nSNAPCHAT BLOCKED: {blocked}")

        assert True