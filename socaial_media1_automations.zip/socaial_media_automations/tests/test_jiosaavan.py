import pytest

from pages.jiosaavn_page import JioSaavnPage

EXPECTED_BLOCKED_STATE = False


class TestJioSaavn:

    @pytest.mark.parametrize(
        "driver",
        ["com.jio.media.jiobeats"],
        indirect=True
    )
    def test_jiosaavn_blocking(self, driver):

        page = JioSaavnPage(
            driver,
            JioSaavnPage.APP_PACKAGE
        )

        blocked = page.validate_blocking()

        print(f"\nJIOSAAVN BLOCKED: {blocked}")

        assert blocked == EXPECTED_BLOCKED_STATE