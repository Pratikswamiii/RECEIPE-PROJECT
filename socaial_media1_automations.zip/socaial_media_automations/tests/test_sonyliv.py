import pytest

from pages.sonyliv_page import SonyLivPage


EXPECTED_BLOCKED_STATE = True


class TestSonyLiv:

    @pytest.mark.parametrize(
        "driver",
        ["com.sonyliv"],
        indirect=True
    )
    def test_sonyliv_blocking(self, driver):

        page = SonyLivPage(
            driver,
            SonyLivPage.APP_PACKAGE
        )

        blocked = page.validate_blocking()

        print(f"\nSONY LIV BLOCKED: {blocked}")

        assert blocked == EXPECTED_BLOCKED_STATEc