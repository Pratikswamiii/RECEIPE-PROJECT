import pytest

from pages.whatsapp_page import WhatsAppPage


EXPECTED_BLOCKED_STATE = False


@pytest.mark.usefixtures("driver")
class TestWhatsapp:

    @pytest.mark.parametrize(
        "driver",
        ["com.whatsapp"],
        indirect=True
    )
    def test_whatsapp_blocking(self, driver):

        page = WhatsAppPage(
            driver,
            WhatsAppPage.APP_PACKAGE
        )

        blocked = page.validate_blocking()

        print(f"\nWHATSAPP BLOCKED: {blocked}")

        assert blocked == EXPECTED_BLOCKED_STATE