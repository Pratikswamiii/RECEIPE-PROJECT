import pytest

from pages.instagram_page import InstagramPage


# TRUE  = app should be blocked
# FALSE = app should work
EXPECTED_BLOCKED_STATE = False


@pytest.mark.usefixtures("driver")
class TestInstagram:

    @pytest.mark.parametrize(
        "driver",
        ["com.instagram.android"],
        indirect=True
    )
    def test_instagram_blocking(self, driver):

        page = InstagramPage(
            driver,
            InstagramPage.APP_PACKAGE
        )

        blocked = page.validate_blocking()

        print(f"\nINSTAGRAM BLOCKED: {blocked}")

        assert blocked == EXPECTED_BLOCKED_STATE